﻿为了便于在 Lite 15.x 中使用大侠们的特别补丁，初步写成这个：Activator.exe

他的主要作用：

1、整合各位大虾的 Keygen
2、相对原始部署方式，这个 Activator 实现“一键激活”！

使用方法：

1、执行 Activator.exe

发布历史：

2019.07.17 - v15.2

1、根据 26.0.34749.6593 原版制作，基于 RADStudioKeyPatch.exe 的成果

2019.02.16 - v15.1

1、根据 26.0.33219.4899 原版制作，基于 RADStudioKeyPatch_Lite.exe 的成果

2018.11.26 - v15.0

1、根据 26.0.32429.4364 原版制作，基于 RadStudioKeygenSourceCodeV10.3.4364.rar 的成果

已知问题：

1、在一些操作系统上如果出现安全提示，直接确定即可。

特别感谢：

1、elseif, tonzi, freecat, unis, x-force, cjack, c5soft 等大侠的特别补丁，感谢诸位我知道的不知道的的大虾们的辛勤劳动！
2、iny、nevergrief、snakejiao、star5、tintin1943、ti9er、wang_80919、wuxiangyang 等等我知道的不知道的的网友们的热情测试！
3、andreas hausladen 等大虾们的无私贡献！

O(∩_∩)O~
