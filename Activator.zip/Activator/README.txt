﻿In order to facilitate the use of the special patch of the heroes in Lite 15.x, initially wrote this: Activator.exe

His main role:

1. Integrate the prawn Keygen
2. Compared to the original deployment method, this Activator implements "one-click activation"!

Instructions:

1. Execute Activator.exe

Release history:

2019.07.17 - v15.2

1. Based on the original version of 26.0.34749.6593, based on the results of RADStudioKeyPatch.exe

2019.02.16 - v15.1

1. Based on the original version of 26.0.33219.4899, based on the results of RADStudioKeyPatch_Lite.exe

2018.11.26 - v15.0

1. Based on the original version of 26.0.32429.4364, based on the results of RadStudioKeygenSourceCodeV10.3.4364.rar

Known issues:

1. If there are security prompts on some operating systems, you can directly determine them.

Special thanks to:

1, elseif, tonzi, freecat, unis, x-force, cjack, c5soft and other heroes special patches, thank you for the hard work of the prawn I know do not know!
2, iny, nevergrief, snakejiao, star5, tintin1943, ti9er, wang_80919, wuxiangyang, etc. I know the enthusiasm of the netizens who do not know!
3, andreas hausladen and other prawn's selfless contribution!

O(∩_∩)O~