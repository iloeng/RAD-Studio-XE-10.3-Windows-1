other:

1. PSDK is no longer available in the current official help documentation.
2, XE7 started, BDE completely disappeared, need a separate installation program, can only be downloaded by official registered users
3, the original version relies on more than 300 megabytes of .NET Framework 3.5 sp1, I extracted the files it depends on into the installer, so it is still the same as the previous lite, only rely on the .NET Framework 2.0.
4. The original Bds.exe and LicenseManager.exe will access the network. To avoid unnecessary traffic, it is strongly recommended to directly block Windows Firewall.

Other source code, support libraries, etc. are absolutely complete.

-------------------------------------------------- ------------------------------

Known issues:

About XP startup error report

Q1: Say: bds.exe - can't find the entry, can't locate the program input point InterlockedCompareExchange64 on the dynamic link library KERNEL32.DLL?
A1: No way, the original version, this API requires Vista or Windows Server 2003 support, indicating that Seattle starts EMB to abandon XP, in fact, only ios compile related dlls need this, such as dcciosxxx, even mongoc also need, if you do not need ios Compile, you can ignore the bypass, click OK

Q2: Start the error of External exception C06D007F? This is a problem with Castalia. The Seattle IDE directly integrates the code of Castalia. XE8 can also close Castalia through the registry. Seattle is not working.
A2: Later Unis heroes patched in the patch: Under XP simulate missing InterlockedCompareExchange64 and add stub functions for missing: AddClipboardFormatListener, RemoveClipboardFormatListener (this why (ex)castalia crash).

Q3: After testing, in versions prior to XP SP3, there was still a problem: the program input point GetLogicalProcessorInformation could not be located on the dynamic link library KERNEL32.dll.
Q3: Can I only expect Unis heroes to shoot again?

other problems:

Q4: How do I need to update and download the Android SDK?
A4: The original version is so; based on the national conditions, directly integrated a "sufficient" (compilation tools, virtual machine images, but not including documents, examples); you can also use the Android SDK provided by swish 23.3.4: http://blog .qdac.cc/?p=2837; or try your own way.

Qn:...
An:...

-------------------------------------------------- ------------------------------

Special Note:

This version comes from the official beta version of the official Beta/RTM, copyrighted by Embarcadero, please delete it within 24 hours of download.
Repackaging is purely personal interest, hoping to facilitate users to test and communicate. As a Fans of Delphi for many years, we all hope that Delphi can do better!
If you think Delphi is good, please buy genuine and better support the development of Embarcadero!

-------------------------------------------------- ------------------------------

Special thanks to:

1, elseif, crackerjack, dr, freecat, gateway, huayan889, kerlingen, sinner, unis, yuto and other heroes special patch, thank you for the hard work of the prawn I know do not know!
2, chineseswish, iny, nevergrief, onechen, snakejiao, star5, swish, tintin1943, ti9er, wang_80919, wuxiangyang, etc. I know the enthusiasm of the netizens who do not know!
3, andreas hausladen and other prawn's selfless contribution!

-------------------------------------------------- ------------------------------

FAQ:

1. The installation program for Embarcadero is now very fast. Why do you need Lite/Repack?

The installation of D2006/2007 has indeed improved a lot. However, there are still long installation days, problems such as leaving a lot of junk files and uninstalling possible garbage. This Lite or Repack is designed to make it easy for Delphiers to try out Delphi's new features while minimizing the impact on the system. As for the use of Lite/Repack or the original version, see people.

2. What is the source of this version?

This version comes from the official beta version of the official Beta/RTM, copyrighted by Embarcadero, please delete it within 24 hours of download. Repackaging is purely personal interest, hoping to facilitate users to test and communicate. As a Fans of Delphi for many years, we all hope that Delphi can do better! If you think Delphi is good, please buy genuine and better support the development of Embarcadero!

3. Is this lite version complete?

Said to be the lite version, in fact, is the Repack part of the original Delphi, all Delphi features are complete. All I did was install the official version in an absolutely clean VMWware XP, except that only Delphi was installed, not including Rave and everything else. The installed Disk file is compared to the original standard, extracting all installed files, registry changes, and then repackaging with Inno. So this is not lite but repack.

4. Can I add a certain function?

That much exchange...

5, there is a problem with xxx
In order to facilitate the use of the special patch of the heroes in Lite 15.x, initially wrote this: Activator.exe

His main role:

1. Integrate the prawn Keygen
2. Compared to the original deployment method, this Activator implements "one-click activation"!

Instructions:

1. Execute Activator.exe

Release history:

2019.11.19 - v15.3

1. Based on the original version of 26.0.36039.7899, based on the results of RADStudioKeyPatch.exe

2019.07.22 - v15.2.1

1. Based on the original version of 26.0.34749.6593, based on the results of RADStudioKeyPatch.exe
2. Improve support for macOS64 based on feedback from wg961423

2019.02.16 - v15.1

1. Based on the original version of 26.0.33219.4899, based on the results of RADStudioKeyPatch_Lite.exe

2018.11.26 - v15.0

1. Based on the original version of 26.0.32429.4364, based on the results of RadStudioKeygenSourceCodeV10.3.4364.rar

Known issues:

1. If there are security prompts on some operating systems, you can directly determine them.

Special thanks to:

1, elseif, tonzi, freecat, unis, x-force, cjack, c5soft and other heroes special patches, thank you for the hard work of the prawn I know do not know!
2, iny, nevergrief, snakejiao, star5, tintin1943, ti9er, wang_80919, wuxiangyang, wg961423, etc. I know the enthusiasm of the netizens who do not know!
3, andreas hausladen and other prawn's selfless contribution!


========================
www.downloadly.ir